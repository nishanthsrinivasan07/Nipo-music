package com.nipo.nipo_music

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()

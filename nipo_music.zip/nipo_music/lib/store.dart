import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

/// All on-device user data: likes, playlists, history and the taste profile that
/// powers the local recommender. Nothing leaves the phone.
class LibraryStore extends ChangeNotifier {
  late SharedPreferences _p;
  List<Track> likes = [];
  List<Track> recent = [];
  List<Playlist> playlists = [];
  List<ArtistLite> favArtists = [];
  List<String> searchHistory = [];
  List<String> pickedGenres = [];
  Map<String, double> affinity = {};
  bool onboarded = false;
  String quality = 'mp32';

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    List<T> list<T>(String k, T Function(Map<String, dynamic>) f) {
      final s = _p.getString(k);
      if (s == null) return [];
      try {
        return (jsonDecode(s) as List).map((e) => f(e as Map<String, dynamic>)).toList();
      } catch (_) {
        return [];
      }
    }

    likes = list('likes', Track.fromJson);
    recent = list('recent', Track.fromJson);
    playlists = list('playlists', Playlist.fromJson);
    favArtists = list('favArtists', ArtistLite.fromJson);
    searchHistory = _p.getStringList('searchHistory') ?? [];
    pickedGenres = _p.getStringList('pickedGenres') ?? [];
    onboarded = _p.getBool('onboarded') ?? false;
    quality = _p.getString('quality') ?? 'mp32';
    final a = _p.getString('affinity');
    if (a != null) {
      try {
        affinity = (jsonDecode(a) as Map).map((k, v) => MapEntry('$k', (v as num).toDouble()));
      } catch (_) {}
    }
  }

  Future<void> _save() async {
    await _p.setString('likes', jsonEncode(likes.map((e) => e.toJson()).toList()));
    await _p.setString('recent', jsonEncode(recent.map((e) => e.toJson()).toList()));
    await _p.setString('playlists', jsonEncode(playlists.map((e) => e.toJson()).toList()));
    await _p.setString('favArtists', jsonEncode(favArtists.map((e) => e.toJson()).toList()));
    await _p.setStringList('searchHistory', searchHistory);
    await _p.setStringList('pickedGenres', pickedGenres);
    await _p.setString('affinity', jsonEncode(affinity));
    await _p.setBool('onboarded', onboarded);
    await _p.setString('quality', quality);
  }

  void _commit() {
    notifyListeners();
    _save();
  }

  // ---- taste profile ----
  void _bump(Iterable<String> tags, double d) {
    for (final t in tags) {
      final v = (affinity[t] ?? 0) + d;
      affinity[t] = v.clamp(-5.0, 40.0).toDouble();
    }
  }

  /// Tags ordered by how much the user likes them.
  List<String> get topTags {
    final e = affinity.entries.where((e) => e.value > 0).toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return e.map((e) => e.key).toList();
  }

  void completeOnboarding(List<String> genres) {
    pickedGenres = genres;
    _bump(genres, 4);
    onboarded = true;
    _commit();
  }

  void setPickedGenres(List<String> genres) {
    final removed = pickedGenres.where((g) => !genres.contains(g));
    _bump(removed, -4);
    _bump(genres.where((g) => !pickedGenres.contains(g)), 4);
    pickedGenres = genres;
    _commit();
  }

  // ---- history ----
  void recordPlay(Track t) {
    recent.removeWhere((e) => e.id == t.id);
    recent.insert(0, t);
    if (recent.length > 60) recent = recent.sublist(0, 60);
    _bump(t.tags, 0.6);
    _commit();
  }

  void recordListenedThrough(Track t) {
    _bump(t.tags, 0.8);
    _commit();
  }

  void recordSkip(Track t) {
    _bump(t.tags, -0.6);
    _commit();
  }

  void clearRecent() {
    recent = [];
    _commit();
  }

  // ---- likes ----
  bool isLiked(Track t) => likes.any((e) => e.id == t.id);

  void toggleLike(Track t) {
    if (isLiked(t)) {
      likes.removeWhere((e) => e.id == t.id);
      _bump(t.tags, -1.5);
    } else {
      likes.insert(0, t);
      _bump(t.tags, 3);
    }
    _commit();
  }

  // ---- artists ----
  bool isFavArtist(String id) => favArtists.any((a) => a.id == id);
  bool isFavArtistName(String name) => favArtists.any((a) => a.name == name);

  void toggleFavArtist(ArtistLite a) {
    if (isFavArtist(a.id)) {
      favArtists.removeWhere((e) => e.id == a.id);
    } else {
      favArtists.add(a);
    }
    _commit();
  }

  // ---- search history ----
  void addSearch(String q) {
    q = q.trim();
    if (q.isEmpty) return;
    searchHistory.removeWhere((e) => e.toLowerCase() == q.toLowerCase());
    searchHistory.insert(0, q);
    if (searchHistory.length > 15) searchHistory = searchHistory.sublist(0, 15);
    _commit();
  }

  void removeSearch(String q) {
    searchHistory.remove(q);
    _commit();
  }

  void clearSearch() {
    searchHistory = [];
    _commit();
  }

  // ---- playlists ----
  Playlist createPlaylist(String name) {
    final p = Playlist(DateTime.now().microsecondsSinceEpoch.toString(), name.trim(), []);
    playlists.add(p);
    _commit();
    return p;
  }

  void renamePlaylist(Playlist p, String name) {
    p.name = name.trim();
    _commit();
  }

  void deletePlaylist(Playlist p) {
    playlists.removeWhere((e) => e.id == p.id);
    _commit();
  }

  void addToPlaylist(Playlist p, Track t) {
    if (!p.tracks.any((e) => e.id == t.id)) p.tracks.add(t);
    _commit();
  }

  void removeFromPlaylist(Playlist p, Track t) {
    p.tracks.removeWhere((e) => e.id == t.id);
    _commit();
  }

  void setQuality(String q) {
    quality = q;
    _commit();
  }
}

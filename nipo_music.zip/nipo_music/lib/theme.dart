import 'package:flutter/material.dart';

class NipoColors {
  static const bg = Color(0xFF0B0B0F);
  static const surface = Color(0xFF16161D);
  static const surface2 = Color(0xFF20202A);
  static const violet = Color(0xFF7C5CFF);
  static const pink = Color(0xFFFF4F9A);
  static const textDim = Color(0xFF9A9AAE);
  static const gradient = LinearGradient(
    colors: [violet, pink], begin: Alignment.topLeft, end: Alignment.bottomRight);
}

ThemeData nipoTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: NipoColors.bg,
    colorScheme: const ColorScheme.dark(
      primary: NipoColors.violet,
      secondary: NipoColors.pink,
      surface: NipoColors.surface,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: NipoColors.bg, elevation: 0, scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.5),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: NipoColors.bg.withOpacity(0.97),
      indicatorColor: NipoColors.violet.withOpacity(0.25),
      labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
    ),
    textTheme: base.textTheme.apply(fontFamily: 'Roboto'),
    sliderTheme: const SliderThemeData(
      trackHeight: 4, thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
      activeTrackColor: Colors.white, inactiveTrackColor: Color(0x33FFFFFF),
      thumbColor: Colors.white, overlayShape: RoundSliderOverlayShape(overlayRadius: 14),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    dividerColor: Colors.white10,
  );
}

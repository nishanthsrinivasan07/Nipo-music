import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'models.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// Client for the official Jamendo API v3 (Creative Commons / licensed catalogue).
/// The client_id is never hard-coded: it comes from `--dart-define=JAMENDO_CLIENT_ID=...`
/// or from the Android Keystore-backed secure storage (entered in Settings).
class JamendoApi {
  static const _define = String.fromEnvironment('JAMENDO_CLIENT_ID');
  static const _storeKey = 'jamendo_client_id';
  static const _secure = FlutterSecureStorage();
  static const _base = 'https://api.jamendo.com/v3.0';

  String _clientId = _define;
  /// mp31 (~96 kbps), mp32 (~VBR 192+ kbps), ogg, flac. Availability is decided by Jamendo.
  String audioFormat = 'mp32';
  final http.Client _http = http.Client();

  bool get hasKey => _clientId.isNotEmpty;

  Future<void> load() async {
    if (_clientId.isEmpty) {
      try {
        _clientId = await _secure.read(key: _storeKey) ?? '';
      } catch (_) {}
    }
  }

  Future<void> saveKey(String key) async {
    _clientId = key.trim();
    await _secure.write(key: _storeKey, value: _clientId);
  }

  Future<List<dynamic>> _get(String path, Map<String, String> q) async {
    if (!hasKey) throw ApiException('No Jamendo client ID set. Add one in Settings.');
    final uri = Uri.parse('$_base/$path/').replace(queryParameters: {
      'client_id': _clientId,
      'format': 'json',
      ...q,
    });
    try {
      final r = await _http.get(uri).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) throw ApiException('Server error (${r.statusCode})');
      final body = jsonDecode(utf8.decode(r.bodyBytes));
      final code = body['headers']?['code'];
      if (code != 0) throw ApiException('${body['headers']?['error_message'] ?? 'API error'}');
      return body['results'] as List<dynamic>;
    } on ApiException {
      rethrow;
    } catch (_) {
      throw ApiException('Could not reach the music catalogue. Check your connection.');
    }
  }

  Future<List<Track>> tracks({
    String? search,
    List<String> tags = const [],
    List<String> fuzzyTags = const [],
    String? artistId,
    String? albumId,
    String order = 'popularity_month',
    int limit = 25,
    int offset = 0,
  }) async {
    final q = <String, String>{
      'limit': '$limit',
      'offset': '$offset',
      'include': 'musicinfo',
      'audioformat': audioFormat,
      'audiodlformat': 'mp32',
      'order': order,
      'hasimage': 'true',
    };
    if (search != null && search.isNotEmpty) q['search'] = search;
    if (tags.isNotEmpty) q['tags'] = tags.join('+');
    if (fuzzyTags.isNotEmpty) q['fuzzytags'] = fuzzyTags.join('+');
    if (artistId != null) q['artist_id'] = artistId;
    if (albumId != null) q['album_id'] = albumId;
    final res = await _get('tracks', q);
    return res
        .whereType<Map<String, dynamic>>()
        .map(Track.fromJamendo)
        .where((t) => t.audioUrl.isNotEmpty)
        .toList();
  }

  Future<List<ArtistLite>> artists(String name, {int limit = 12}) async {
    final res = await _get('artists', {'namesearch': name, 'limit': '$limit', 'hasimage': 'true'});
    return res.whereType<Map<String, dynamic>>().map(ArtistLite.fromJamendo).toList();
  }

  Future<List<AlbumLite>> albums(String name, {int limit = 12}) async {
    final res = await _get('albums', {'namesearch': name, 'limit': '$limit', 'imagesize': '300'});
    return res.whereType<Map<String, dynamic>>().map(AlbumLite.fromJamendo).toList();
  }
}

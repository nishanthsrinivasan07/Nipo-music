import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'jamendo_api.dart';
import 'player.dart';
import 'recommender.dart';
import 'store.dart';
import 'theme.dart';
import 'ui/onboarding.dart';
import 'ui/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.nipo.nipo_music.playback',
    androidNotificationChannelName: 'NIPO MUSIC playback',
    androidNotificationOngoing: true,
  );
  final api = JamendoApi();
  final store = LibraryStore();
  await Future.wait([api.load(), store.load()]);
  api.audioFormat = store.quality;
  final player = PlayerController(store);
  await player.init();
  runApp(MultiProvider(
    providers: [
      Provider<JamendoApi>.value(value: api),
      ChangeNotifierProvider<LibraryStore>.value(value: store),
      Provider<Recommender>(create: (_) => Recommender(api, store)),
      ChangeNotifierProvider<PlayerController>.value(value: player),
    ],
    child: const NipoApp(),
  ));
}

class NipoApp extends StatelessWidget {
  const NipoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NIPO MUSIC',
        debugShowCheckedModeBanner: false,
        theme: nipoTheme(),
        home: const _Splash(),
      );
}

/// Animated splash, then onboarding (first launch) or the main shell.
class _Splash extends StatefulWidget {
  const _Splash();
  @override
  State<_Splash> createState() => _SplashState();
}

class _SplashState extends State<_Splash> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();
  bool _done = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) setState(() => _done = true);
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_done) {
      final store = context.read<LibraryStore>();
      return store.onboarded
          ? const Shell()
          : OnboardingScreen(onDone: () => setState(() {}));
    }
    return Scaffold(
      body: Center(
        child: FadeTransition(
          opacity: CurvedAnimation(parent: _c, curve: Curves.easeOut),
          child: ScaleTransition(
            scale: Tween(begin: 0.85, end: 1.0)
                .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutBack)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: Image.asset('assets/icon/icon.png', width: 112, height: 112),
              ),
              const SizedBox(height: 22),
              ShaderMask(
                shaderCallback: (r) => NipoColors.gradient.createShader(r),
                child: const Text('NIPO MUSIC',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900,
                        letterSpacing: 3, color: Colors.white)),
              ),
              const SizedBox(height: 8),
              const Text('Music. Discovered differently.',
                  style: TextStyle(color: NipoColors.textDim, letterSpacing: 0.5)),
            ]),
          ),
        ),
      ),
    );
  }
}

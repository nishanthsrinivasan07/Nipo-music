import 'dart:math';
import 'jamendo_api.dart';
import 'models.dart';
import 'store.dart';

/// Genres offered during onboarding and on Discover (Jamendo tag names).
const kGenres = <String, String>{
  'pop': 'Pop', 'rock': 'Rock', 'electronic': 'Electronic', 'hiphop': 'Hip-Hop',
  'jazz': 'Jazz', 'classical': 'Classical', 'ambient': 'Ambient', 'folk': 'Folk',
  'indie': 'Indie', 'metal': 'Metal', 'reggae': 'Reggae', 'blues': 'Blues',
  'soundtrack': 'Cinematic', 'lounge': 'Lounge', 'country': 'Country', 'funk': 'Funk',
};

class Mood {
  final String name, emoji;
  final List<String> tags;
  const Mood(this.name, this.emoji, this.tags);
}

const kMoods = <Mood>[
  Mood('Chill', '🌊', ['chillout', 'relaxing', 'ambient']),
  Mood('Energetic', '⚡', ['energetic', 'dance', 'rock']),
  Mood('Happy', '☀️', ['happy', 'upbeat', 'pop']),
  Mood('Focus', '🎯', ['instrumental', 'ambient', 'piano']),
  Mood('Melancholy', '🌧️', ['sad', 'melancholic', 'piano']),
  Mood('Workout', '🔥', ['energetic', 'electronic', 'powerful']),
  Mood('Romantic', '🌹', ['romantic', 'love', 'soft']),
  Mood('Epic', '🏔️', ['epic', 'cinematic', 'dramatic']),
  Mood('Late night', '🌙', ['dark', 'trip-hop', 'downtempo']),
];

/// Fully local recommender: content-based scoring over Jamendo tags using a taste
/// profile built from likes, plays, skips, favourite artists and chosen genres.
/// No AI API, no network calls other than the catalogue itself.
class Recommender {
  final JamendoApi api;
  final LibraryStore store;
  final _rng = Random();
  Object? _lastError;
  Recommender(this.api, this.store);

  double score(Track t) {
    double s = 0;
    for (final tag in t.tags) {
      s += store.affinity[tag] ?? 0;
    }
    if (store.isFavArtistName(t.artist)) s += 6;
    if (store.recent.take(20).any((r) => r.id == t.id)) s -= 8; // keep it fresh
    if (store.isLiked(t)) s -= 4; // they already know it
    return s + _rng.nextDouble(); // tiny jitter so refreshes differ
  }

  List<Track> _rank(Iterable<Track> pool, {int take = 20}) {
    final seen = <String>{};
    final unique = pool.where((t) => seen.add(t.id)).toList();
    unique.sort((a, b) => score(b).compareTo(score(a)));
    // diversity: at most 3 tracks per artist
    final perArtist = <String, int>{};
    final out = <Track>[];
    for (final t in unique) {
      final n = perArtist[t.artistId] ?? 0;
      if (n >= 3) continue;
      perArtist[t.artistId] = n + 1;
      out.add(t);
      if (out.length >= take) break;
    }
    return out;
  }

  Future<List<Track>> _safe(Future<List<Track>> f) async {
    try {
      return await f;
    } catch (e) {
      _lastError = e;
      return [];
    }
  }

  Future<List<Shelf>> homeShelves() async {
    _lastError = null;
    final shelves = <Shelf>[];
    final tags = store.topTags;
    final futures = <Future<void>>[];

    if (tags.isNotEmpty) {
      futures.add(() async {
        final pool = await _safe(api.tracks(fuzzyTags: tags.take(3).toList(), limit: 50));
        final r = _rank(pool);
        if (r.isNotEmpty) {
          shelves.add(Shelf('Made for you', r,
              subtitle: 'Based on ${tags.take(3).map(_label).join(', ')}'));
        }
      }());
    }
    if (store.likes.isNotEmpty) {
      final seed = store.likes.first;
      futures.add(() async {
        final r = await similarTo(seed);
        if (r.isNotEmpty) shelves.add(Shelf('Because you liked ${seed.title}', r));
      }());
    }
    for (final g in tags.skip(3).take(2)) {
      futures.add(() async {
        final r = _rank(await _safe(api.tracks(tags: [g], limit: 30)), take: 15);
        if (r.isNotEmpty) shelves.add(Shelf('More ${_label(g)}', r));
      }());
    }
    futures.add(() async {
      final r = await _safe(api.tracks(order: 'popularity_week', limit: 20));
      if (r.isNotEmpty) shelves.add(Shelf('Trending this week', r));
    }());
    futures.add(() async {
      final r = await _safe(api.tracks(
          fuzzyTags: tags.take(2).toList(), order: 'releasedate_desc', limit: 20));
      if (r.isNotEmpty) shelves.add(Shelf('Fresh finds', r, subtitle: 'New releases'));
    }());
    await Future.wait(futures);
    if (shelves.isEmpty) {
      throw _lastError ?? ApiException('The catalogue returned nothing. Try again in a moment.');
    }
    const order = ['Made for you', 'Because', 'More', 'Trending', 'Fresh'];
    int rank(Shelf s) {
      final i = order.indexWhere((o) => s.title.startsWith(o));
      return i < 0 ? 99 : i;
    }
    shelves.sort((a, b) => rank(a).compareTo(rank(b)));
    return shelves;
  }

  /// Tracks sharing the seed's tags, excluding the seed itself.
  Future<List<Track>> similarTo(Track seed) async {
    final tags = seed.tags.isNotEmpty ? seed.tags.take(3).toList() : store.topTags.take(2).toList();
    if (tags.isEmpty) return [];
    final pool = await _safe(api.tracks(fuzzyTags: tags, limit: 40));
    return _rank(pool.where((t) => t.id != seed.id), take: 20);
  }

  /// Similar artists = artists of the best-matching tracks that aren't this artist.
  Future<List<Track>> similarToArtist(String artistId, List<String> tags) async {
    if (tags.isEmpty) return [];
    final pool = await _safe(api.tracks(fuzzyTags: tags.take(3).toList(), limit: 40));
    return _rank(pool.where((t) => t.artistId != artistId), take: 15);
  }

  Future<List<Track>> forMood(Mood m) async {
    final pool = await api.tracks(fuzzyTags: m.tags, limit: 50);
    return _rank(pool, take: 30);
  }

  Future<List<Track>> forGenre(String g) async {
    final pool = await api.tracks(tags: [g], limit: 50);
    return _rank(pool, take: 30);
  }

  static String _label(String tag) => kGenres[tag] ?? (tag[0].toUpperCase() + tag.substring(1));
}

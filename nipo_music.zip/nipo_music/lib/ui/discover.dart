import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../player.dart';
import '../recommender.dart';
import '../store.dart';
import '../theme.dart';
import 'detail.dart';
import 'widgets.dart';

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Discover')),
      body: ListView(padding: const EdgeInsets.only(bottom: 120), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => _surprise(context),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                  gradient: NipoColors.gradient, borderRadius: BorderRadius.circular(18)),
              child: Row(children: [
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Surprise me',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    SizedBox(height: 4),
                    Text('A mix that stretches your taste a little.',
                        style: TextStyle(color: Colors.white70)),
                  ]),
                ),
                const Icon(Icons.auto_awesome_rounded, size: 36),
              ]),
            ),
          ),
        ),
        const SectionHeader('Moods', subtitle: 'Pick a feeling, we’ll find the music'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 2, shrinkWrap: true, childAspectRatio: 2.4,
            mainAxisSpacing: 10, crossAxisSpacing: 10,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              for (final m in kMoods)
                InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                      context, MaterialPageRoute(builder: (_) => TrackListPage.mood(m))),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                        color: NipoColors.surface, borderRadius: BorderRadius.circular(14)),
                    child: Row(children: [
                      Text(m.emoji, style: const TextStyle(fontSize: 22)),
                      const SizedBox(width: 10),
                      Text(m.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
            ],
          ),
        ),
        const SectionHeader('Genre playlists'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 2, shrinkWrap: true, childAspectRatio: 2.4,
            mainAxisSpacing: 10, crossAxisSpacing: 10,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              for (final g in kGenres.entries)
                InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                      context, MaterialPageRoute(builder: (_) => TrackListPage.genre(g.key))),
                  child: Container(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: LinearGradient(colors: [
                        NipoColors.violet.withOpacity(store.pickedGenres.contains(g.key) ? 0.7 : 0.25),
                        NipoColors.surface,
                      ]),
                    ),
                    child: Text(g.value, style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
            ],
          ),
        ),
      ]),
    );
  }

  /// Picks a genre the user has NOT listened to much and plays a mix of it.
  Future<void> _surprise(BuildContext context) async {
    final store = context.read<LibraryStore>();
    final rec = context.read<Recommender>();
    final pc = context.read<PlayerController>();
    final messenger = ScaffoldMessenger.of(context);
    final unexplored = kGenres.keys
        .where((g) => (store.affinity[g] ?? 0) < 1)
        .toList()
      ..shuffle();
    final g = unexplored.isEmpty ? (kGenres.keys.toList()..shuffle()).first : unexplored.first;
    messenger.showSnackBar(SnackBar(content: Text('Finding some ${kGenres[g]}…')));
    try {
      final tracks = await rec.forGenre(g);
      if (tracks.isEmpty) throw Exception('empty');
      await pc.playQueue(tracks);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('$e'.contains('client ID')
          ? 'Add a Jamendo client ID in Settings first.'
          : 'Could not load a mix. Try again.')));
    }
  }
}

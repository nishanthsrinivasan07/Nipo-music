import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../recommender.dart';
import '../store.dart';
import '../theme.dart';

class OnboardingScreen extends StatefulWidget {
  final VoidCallback onDone;
  const OnboardingScreen({super.key, required this.onDone});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _sel = <String>{};
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 20),
              ShaderMask(
                shaderCallback: (r) => NipoColors.gradient.createShader(r),
                child: const Text('What do you\nlove to hear?',
                    style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, height: 1.05, color: Colors.white)),
              ),
              const SizedBox(height: 10),
              const Text('Pick a few genres to start your taste profile. You can change this anytime.',
                  style: TextStyle(color: NipoColors.textDim)),
              const SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: Wrap(spacing: 10, runSpacing: 10, children: [
                    for (final g in kGenres.entries)
                      FilterChip(
                        label: Text(g.value, style: const TextStyle(fontSize: 15)),
                        selected: _sel.contains(g.key),
                        showCheckmark: false,
                        selectedColor: NipoColors.violet,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                        onSelected: (on) => setState(() => on ? _sel.add(g.key) : _sel.remove(g.key)),
                      ),
                  ]),
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
                  onPressed: () {
                    context.read<LibraryStore>().completeOnboarding(_sel.toList());
                    widget.onDone();
                  },
                  child: Text(_sel.isEmpty ? 'Skip for now' : 'Continue (${_sel.length})'),
                ),
              ),
            ]),
          ),
        ),
      );
}

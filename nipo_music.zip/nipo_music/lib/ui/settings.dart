import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../jamendo_api.dart';
import '../recommender.dart';
import '../store.dart';
import '../theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _key = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final api = context.read<JamendoApi>();
    final store = context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 40), children: [
        _h('Music catalogue'),
        Text(
          api.hasKey
              ? 'Jamendo client ID is set. Stored in Android Keystore-backed secure storage.'
              : 'NIPO MUSIC streams licensed, Creative Commons music from Jamendo. '
                  'Create a free app at devportal.jamendo.com and paste the client ID here.',
          style: const TextStyle(color: NipoColors.textDim, height: 1.4),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _key,
          obscureText: true,
          decoration: InputDecoration(
            hintText: api.hasKey ? '••••••••  (enter a new ID to replace)' : 'Jamendo client ID',
            filled: true, fillColor: NipoColors.surface,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          ),
        ),
        Row(children: [
          TextButton(
            onPressed: () => launchUrl(Uri.parse('https://devportal.jamendo.com'),
                mode: LaunchMode.externalApplication),
            child: const Text('Get a client ID'),
          ),
          const Spacer(),
          FilledButton(
            onPressed: () async {
              if (_key.text.trim().isEmpty) return;
              await api.saveKey(_key.text);
              _key.clear();
              if (mounted) {
                setState(() {});
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('Saved. Pull to refresh Home.')));
              }
            },
            child: const Text('Save'),
          ),
        ]),
        _h('Streaming quality'),
        for (final q in const [
          ['mp31', 'Standard', 'MP3, ~96 kbps · saves data'],
          ['mp32', 'High', 'MP3, higher bitrate (default)'],
          ['flac', 'Lossless (if offered)', 'FLAC where Jamendo provides it · large files'],
        ])
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(q[1]),
            subtitle: Text(q[2], style: const TextStyle(color: NipoColors.textDim)),
            trailing: store.quality == q[0]
                ? const Icon(Icons.check_circle_rounded, color: NipoColors.pink)
                : const Icon(Icons.circle_outlined, color: Colors.white24),
            onTap: () {
              store.setQuality(q[0]);
              api.audioFormat = q[0];
            },
          ),
        const Text('Quality applies to songs loaded from now on.',
            style: TextStyle(color: NipoColors.textDim, fontSize: 12.5)),
        _h('Your taste'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final g in kGenres.entries)
            FilterChip(
              label: Text(g.value),
              selected: store.pickedGenres.contains(g.key),
              onSelected: (on) {
                final l = List<String>.of(store.pickedGenres);
                on ? l.add(g.key) : l.remove(g.key);
                store.setPickedGenres(l);
              },
            ),
        ]),
        const SizedBox(height: 10),
        const Text(
          'Recommendations are computed on your phone from your likes, plays, skips, '
          'favourite artists and these genres. No data is sent to any AI service.',
          style: TextStyle(color: NipoColors.textDim, height: 1.4),
        ),
        _h('Privacy'),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Clear search history'),
          onTap: store.clearSearch,
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Clear recently played'),
          onTap: store.clearRecent,
        ),
        _h('About'),
        const Text(
          'NIPO MUSIC shows no advertisements and contains no advertising SDK. '
          'Music is provided by Jamendo under each artist’s Creative Commons licence '
          '(tap “License” in the player). Jamendo’s own terms apply to the catalogue.',
          style: TextStyle(color: NipoColors.textDim, height: 1.4),
        ),
      ]),
    );
  }

  Widget _h(String t) => Padding(
        padding: const EdgeInsets.only(top: 24, bottom: 8),
        child: Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      );
}

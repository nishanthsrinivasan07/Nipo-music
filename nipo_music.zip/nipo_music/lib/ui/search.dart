import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../jamendo_api.dart';
import '../models.dart';
import '../recommender.dart';
import '../store.dart';
import '../theme.dart';
import 'detail.dart';
import 'widgets.dart';

class _Results {
  final List<Track> tracks;
  final List<ArtistLite> artists;
  final List<AlbumLite> albums;
  _Results(this.tracks, this.artists, this.albums);
}

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _c = TextEditingController();
  Future<_Results>? _f;
  String _q = '';

  void _run(String q) {
    q = q.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    _c.text = q;
    context.read<LibraryStore>().addSearch(q);
    final api = context.read<JamendoApi>();
    setState(() {
      _q = q;
      _f = () async {
        final r = await Future.wait([
          api.tracks(search: q, order: 'relevance', limit: 30),
          api.artists(q).catchError((_) => <ArtistLite>[]),
          api.albums(q).catchError((_) => <AlbumLite>[]),
        ]);
        return _Results(r[0] as List<Track>, r[1] as List<ArtistLite>, r[2] as List<AlbumLite>);
      }();
    });
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: TextField(
            controller: _c,
            textInputAction: TextInputAction.search,
            onSubmitted: _run,
            onChanged: (v) => setState(() {
              if (v.isEmpty) _f = null;
            }),
            decoration: InputDecoration(
              hintText: 'Songs, artists, albums, genres',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _c.text.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () => setState(() {
                        _c.clear();
                        _f = null;
                      })),
              filled: true,
              fillColor: NipoColors.surface,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(child: _f == null ? _idle(store) : _results()),
      ]),
    );
  }

  Widget _idle(LibraryStore store) => ListView(padding: const EdgeInsets.only(bottom: 120), children: [
        if (store.searchHistory.isNotEmpty) ...[
          SectionHeader('Recent searches',
              trailing: TextButton(onPressed: store.clearSearch, child: const Text('Clear'))),
          for (final h in store.searchHistory)
            ListTile(
              dense: true,
              leading: const Icon(Icons.history_rounded, color: NipoColors.textDim),
              title: Text(h),
              trailing: IconButton(
                  icon: const Icon(Icons.close_rounded, size: 18),
                  onPressed: () => store.removeSearch(h)),
              onTap: () => _run(h),
            ),
        ],
        const SectionHeader('Browse genres'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Wrap(spacing: 8, runSpacing: 8, children: [
            for (final g in kGenres.entries)
              ActionChip(
                label: Text(g.value),
                backgroundColor: NipoColors.surface,
                onPressed: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => TrackListPage.genre(g.key))),
              ),
          ]),
        ),
      ]);

  Widget _results() => FutureBuilder<_Results>(
        future: _f,
        builder: (c, snap) {
          if (snap.connectionState != ConnectionState.done) return const Loading();
          if (snap.hasError) return errorState(snap.error!, () => _run(_q));
          final r = snap.data!;
          if (r.tracks.isEmpty && r.artists.isEmpty && r.albums.isEmpty) {
            return StateMessage(Icons.search_off_rounded, 'No results for “$_q”',
                body: 'Try a different spelling, or browse a genre.');
          }
          return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
            if (r.artists.isNotEmpty) ...[
              const SectionHeader('Artists'),
              SizedBox(
                height: 130,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: r.artists.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 16),
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => TrackListPage.artist(r.artists[i]))),
                    child: SizedBox(
                      width: 90,
                      child: Column(children: [
                        Artwork(r.artists[i].image, size: 90, radius: 45),
                        const SizedBox(height: 6),
                        Text(r.artists[i].name,
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
                ),
              ),
            ],
            if (r.albums.isNotEmpty) ...[
              const SectionHeader('Albums'),
              SizedBox(
                height: 180,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: r.albums.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => TrackListPage.album(r.albums[i]))),
                    child: SizedBox(
                      width: 120,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Artwork(r.albums[i].image, size: 120, radius: 10),
                        const SizedBox(height: 6),
                        Text(r.albums[i].name,
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                        Text(r.albums[i].artist,
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: NipoColors.textDim, fontSize: 12)),
                      ]),
                    ),
                  ),
                ),
              ),
            ],
            if (r.tracks.isNotEmpty) ...[
              const SectionHeader('Songs'),
              for (final t in r.tracks) TrackTile(t, r.tracks),
            ],
          ]);
        },
      );
}

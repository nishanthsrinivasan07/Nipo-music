import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../player.dart';
import '../store.dart';
import '../theme.dart';
import 'widgets.dart';

String _fmt(Duration d) {
  final m = d.inMinutes, s = d.inSeconds % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});
  @override
  Widget build(BuildContext context) {
    final pc = context.watch<PlayerController>();
    final t = pc.current;
    if (t == null) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => openPlayer(context),
      child: Container(
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 6),
        decoration: BoxDecoration(
            color: NipoColors.surface2, borderRadius: BorderRadius.circular(14)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            dense: true,
            contentPadding: const EdgeInsets.only(left: 8, right: 4),
            leading: Artwork(t.image, size: 44),
            title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(t.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: NipoColors.textDim)),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              StreamBuilder<PlayerState>(
                stream: pc.player.playerStateStream,
                builder: (_, s) {
                  final playing = s.data?.playing ?? false;
                  return pc.loading
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(width: 22, height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2.5)))
                      : IconButton(
                          icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 30),
                          onPressed: pc.togglePlay);
                },
              ),
              IconButton(icon: const Icon(Icons.skip_next_rounded), onPressed: pc.next),
            ]),
          ),
          StreamBuilder<Duration>(
            stream: pc.player.positionStream,
            builder: (_, s) {
              final total = (pc.player.duration ?? Duration(seconds: t.duration)).inMilliseconds;
              final v = total == 0 ? 0.0 : (s.data?.inMilliseconds ?? 0) / total;
              return ClipRRect(
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
                child: LinearProgressIndicator(
                    value: v.clamp(0.0, 1.0).toDouble(), minHeight: 2.5,
                    backgroundColor: Colors.white10, color: NipoColors.pink),
              );
            },
          ),
        ]),
      ),
    );
  }
}

void openPlayer(BuildContext context) {
  showGeneralDialog(
    context: context,
    barrierDismissible: false,
    transitionDuration: const Duration(milliseconds: 320),
    pageBuilder: (_, __, ___) => const PlayerScreen(),
    transitionBuilder: (_, a, __, child) => SlideTransition(
      position: Tween(begin: const Offset(0, 1), end: Offset.zero)
          .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
      child: child,
    ),
  );
}

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final pc = context.watch<PlayerController>();
    final store = context.watch<LibraryStore>();
    final t = pc.current;
    if (t == null) return const Scaffold(body: StateMessage(Icons.music_off_rounded, 'Nothing playing'));
    final liked = store.isLiked(t);
    final mq = MediaQuery.of(context).size;
    final art = math.min(mq.width - 64, mq.height * 0.36);
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [NipoColors.violet.withOpacity(0.35), NipoColors.bg, NipoColors.bg],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(children: [
              Row(children: [
                IconButton(
                    icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
                    onPressed: () => Navigator.pop(context)),
                const Expanded(
                  child: Text('NOW PLAYING', textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, letterSpacing: 2, color: NipoColors.textDim)),
                ),
                IconButton(
                    icon: const Icon(Icons.more_horiz_rounded),
                    onPressed: () => showTrackMenu(context, t)),
              ]),
              const Spacer(),
              Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(color: NipoColors.pink.withOpacity(0.25), blurRadius: 50, spreadRadius: 2)
                ]),
                child: Artwork(t.image, size: art, radius: 20),
              ),
              const Spacer(),
              Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    Text(t.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 16, color: NipoColors.textDim)),
                  ]),
                ),
                IconButton(
                  iconSize: 28,
                  icon: Icon(liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      color: liked ? NipoColors.pink : null),
                  onPressed: () => store.toggleLike(t),
                ),
              ]),
              if (pc.error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(pc.error!, style: const TextStyle(color: Colors.orangeAccent)),
                ),
              const SizedBox(height: 8),
              _SeekBar(pc, t.duration),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                IconButton(
                  icon: Icon(Icons.shuffle_rounded,
                      color: pc.player.shuffleModeEnabled ? NipoColors.pink : Colors.white54),
                  onPressed: pc.toggleShuffle,
                ),
                IconButton(iconSize: 38, icon: const Icon(Icons.skip_previous_rounded), onPressed: pc.previous),
                StreamBuilder<PlayerState>(
                  stream: pc.player.playerStateStream,
                  builder: (_, s) {
                    final playing = s.data?.playing ?? false;
                    return Container(
                      width: 68, height: 68,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                      child: pc.loading
                          ? const Padding(
                              padding: EdgeInsets.all(20),
                              child: CircularProgressIndicator(strokeWidth: 3, color: Colors.black))
                          : IconButton(
                              iconSize: 40, color: Colors.black,
                              icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                              onPressed: pc.togglePlay),
                    );
                  },
                ),
                IconButton(iconSize: 38, icon: const Icon(Icons.skip_next_rounded), onPressed: pc.next),
                IconButton(
                  icon: Icon(
                    pc.player.loopMode == LoopMode.one ? Icons.repeat_one_rounded : Icons.repeat_rounded,
                    color: pc.player.loopMode == LoopMode.off ? Colors.white54 : NipoColors.pink),
                  onPressed: pc.cycleRepeat,
                ),
              ]),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                TextButton.icon(
                  onPressed: () => _queue(context),
                  icon: const Icon(Icons.queue_music_rounded, size: 20),
                  label: Text('Queue (${pc.queue.length})'),
                ),
                if (t.license.isNotEmpty)
                  TextButton.icon(
                    onPressed: () => launchUrl(Uri.parse(t.license), mode: LaunchMode.externalApplication),
                    icon: const Icon(Icons.info_outline_rounded, size: 18),
                    label: const Text('License'),
                  ),
              ]),
              const SizedBox(height: 8),
            ]),
          ),
        ),
      ),
    );
  }

  void _queue(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: NipoColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => ChangeNotifierProvider.value(
        value: context.read<PlayerController>(),
        child: const _QueueSheet(),
      ),
    );
  }
}

class _SeekBar extends StatefulWidget {
  final PlayerController pc;
  final int fallbackSeconds;
  const _SeekBar(this.pc, this.fallbackSeconds);
  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;
  @override
  Widget build(BuildContext context) {
    final p = widget.pc.player;
    return StreamBuilder<Duration>(
      stream: p.positionStream,
      builder: (_, s) {
        final total = (p.duration ?? Duration(seconds: widget.fallbackSeconds)).inMilliseconds.toDouble();
        final pos = (s.data?.inMilliseconds.toDouble() ?? 0.0).clamp(0.0, total <= 0 ? 1.0 : total).toDouble();
        final val = _drag ?? pos;
        return Column(children: [
          Slider(
            min: 0,
            max: total <= 0 ? 1 : total,
            value: val.clamp(0.0, total <= 0 ? 1.0 : total).toDouble(),
            onChanged: (v) => setState(() => _drag = v),
            onChangeEnd: (v) {
              widget.pc.seek(Duration(milliseconds: v.round()));
              setState(() => _drag = null);
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(_fmt(Duration(milliseconds: val.round())),
                  style: const TextStyle(fontSize: 12, color: NipoColors.textDim)),
              Text(_fmt(Duration(milliseconds: total.round())),
                  style: const TextStyle(fontSize: 12, color: NipoColors.textDim)),
            ]),
          ),
        ]);
      },
    );
  }
}

class _QueueSheet extends StatelessWidget {
  const _QueueSheet();
  @override
  Widget build(BuildContext context) {
    final pc = context.watch<PlayerController>();
    return DraggableScrollableSheet(
      expand: false, initialChildSize: 0.7, maxChildSize: 0.92,
      builder: (_, scroll) => Column(children: [
        const SizedBox(height: 12),
        Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
        const Padding(
          padding: EdgeInsets.all(16),
          child: Text('Up next', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ),
        Expanded(
          child: pc.queue.isEmpty
              ? const StateMessage(Icons.queue_music_rounded, 'Queue is empty')
              : ReorderableListView.builder(
                  scrollController: scroll,
                  itemCount: pc.queue.length,
                  onReorder: (a, b) {
                    if (b > a) b -= 1;
                    pc.moveInQueue(a, b);
                  },
                  itemBuilder: (_, i) {
                    final t = pc.queue[i];
                    final now = i == pc.index;
                    return Dismissible(
                      key: ValueKey('${t.id}-$i'),
                      direction: DismissDirection.endToStart,
                      background: Container(
                          color: Colors.red.withOpacity(0.4),
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          child: const Icon(Icons.delete_outline_rounded)),
                      onDismissed: (_) => pc.removeFromQueue(i),
                      child: ListTile(
                        leading: Artwork(t.image, size: 44),
                        title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: now ? NipoColors.pink : Colors.white)),
                        subtitle: Text(t.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: NipoColors.textDim)),
                        trailing: ReorderableDragStartListener(
                            index: i, child: const Icon(Icons.drag_handle_rounded)),
                        onTap: () => pc.jumpTo(i),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

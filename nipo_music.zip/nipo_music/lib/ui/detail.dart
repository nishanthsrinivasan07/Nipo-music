import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../jamendo_api.dart';
import '../models.dart';
import '../player.dart';
import '../recommender.dart';
import '../store.dart';
import '../theme.dart';
import 'widgets.dart';

typedef TrackLoader = Future<List<Track>> Function(BuildContext c);

/// One page used for artists, albums, genres and moods.
class TrackListPage extends StatefulWidget {
  final String title, subtitle, image;
  final TrackLoader loader;
  final ArtistLite? artist;

  const TrackListPage._(this.title, this.subtitle, this.image, this.loader, {this.artist});

  TrackListPage.artist(ArtistLite a, {super.key})
      : title = a.name,
        subtitle = 'Artist',
        image = a.image,
        artist = a,
        loader = ((c) => c.read<JamendoApi>().tracks(
            artistId: a.id, order: 'popularity_total', limit: 40));

  TrackListPage.album(AlbumLite a, {super.key})
      : title = a.name,
        subtitle = 'Album · ${a.artist}',
        image = a.image,
        artist = null,
        loader = ((c) => c.read<JamendoApi>().tracks(
            albumId: a.id, order: 'popularity_total', limit: 60));

  TrackListPage.genre(String tag, {super.key})
      : title = kGenres[tag] ?? tag,
        subtitle = 'Genre playlist',
        image = '',
        artist = null,
        loader = ((c) => c.read<Recommender>().forGenre(tag));

  TrackListPage.mood(Mood m, {super.key})
      : title = '${m.emoji} ${m.name}',
        subtitle = 'Mood mix',
        image = '',
        artist = null,
        loader = ((c) => c.read<Recommender>().forMood(m));

  @override
  State<TrackListPage> createState() => _TrackListPageState();
}

class _TrackListPageState extends State<TrackListPage> {
  late Future<List<Track>> _f;
  Future<List<Track>>? _similar;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    _f = widget.loader(context);
    if (widget.artist != null) {
      _similar = _f.then((tracks) {
        final freq = <String, int>{};
        for (final t in tracks) {
          for (final g in t.tags) {
            freq[g] = (freq[g] ?? 0) + 1;
          }
        }
        final tags = (freq.entries.toList()..sort((a, b) => b.value.compareTo(a.value)))
            .map((e) => e.key)
            .toList();
        return context.read<Recommender>().similarToArtist(widget.artist!.id, tags);
      }).catchError((_) => <Track>[]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pc = context.read<PlayerController>();
    return Scaffold(
      appBar: AppBar(),
      body: FutureBuilder<List<Track>>(
        future: _f,
        builder: (c, snap) {
          if (snap.connectionState != ConnectionState.done) return const Loading();
          if (snap.hasError) return errorState(snap.error!, () => setState(_load));
          final tracks = snap.data!;
          if (tracks.isEmpty) {
            return const StateMessage(Icons.music_off_rounded, 'No songs found',
                body: 'The catalogue has nothing here yet.');
          }
          final img = widget.image.isNotEmpty ? widget.image : tracks.first.image;
          return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
            Center(child: Artwork(img, size: 200, radius: widget.artist != null ? 100 : 16)),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(children: [
                Text(widget.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                Text(widget.subtitle, style: const TextStyle(color: NipoColors.textDim)),
              ]),
            ),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FilledButton.icon(
                onPressed: () => pc.playQueue(tracks),
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text('Play'),
              ),
              const SizedBox(width: 10),
              OutlinedButton.icon(
                onPressed: () => pc.playQueue(List.of(tracks)..shuffle()),
                icon: const Icon(Icons.shuffle_rounded),
                label: const Text('Shuffle'),
              ),
              if (widget.artist != null) ...[
                const SizedBox(width: 10),
                Consumer<LibraryStore>(
                  builder: (_, s, __) => IconButton.outlined(
                    onPressed: () => s.toggleFavArtist(
                        ArtistLite(widget.artist!.id, widget.artist!.name, img)),
                    icon: Icon(s.isFavArtist(widget.artist!.id)
                        ? Icons.favorite
                        : Icons.favorite_border),
                    color: NipoColors.pink,
                  ),
                ),
              ],
            ]),
            const SizedBox(height: 12),
            for (var i = 0; i < tracks.length; i++) TrackTile(tracks[i], tracks),
            if (_similar != null)
              FutureBuilder<List<Track>>(
                future: _similar,
                builder: (_, s) => (s.data == null || s.data!.isEmpty)
                    ? const SizedBox.shrink()
                    : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const SectionHeader('Fans also like',
                            subtitle: 'Similar sound, other artists'),
                        TrackShelf(s.data!),
                      ]),
              ),
          ]);
        },
      ),
    );
  }
}

class PlaylistPage extends StatelessWidget {
  final Playlist playlist;
  const PlaylistPage(this.playlist, {super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final pc = context.read<PlayerController>();
    final exists = store.playlists.any((p) => p.id == playlist.id);
    return Scaffold(
      appBar: AppBar(
        title: Text(playlist.name),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'rename') {
                final n = await askText(context, 'Rename playlist', initial: playlist.name);
                if (n != null && n.trim().isNotEmpty) store.renamePlaylist(playlist, n);
              } else {
                store.deletePlaylist(playlist);
                Navigator.pop(context);
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'rename', child: Text('Rename')),
              PopupMenuItem(value: 'delete', child: Text('Delete playlist')),
            ],
          ),
        ],
      ),
      body: !exists
          ? const SizedBox.shrink()
          : playlist.tracks.isEmpty
              ? const StateMessage(Icons.queue_music_rounded, 'This playlist is empty',
                  body: 'Use ••• on any song and choose “Add to playlist”.')
              : ListView(padding: const EdgeInsets.only(bottom: 120), children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => pc.playQueue(playlist.tracks),
                          icon: const Icon(Icons.play_arrow_rounded),
                          label: const Text('Play'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => pc.playQueue(List.of(playlist.tracks)..shuffle()),
                          icon: const Icon(Icons.shuffle_rounded),
                          label: const Text('Shuffle'),
                        ),
                      ),
                    ]),
                  ),
                  for (final t in playlist.tracks)
                    TrackTile(t, playlist.tracks,
                        onRemove: () => store.removeFromPlaylist(playlist, t)),
                ]),
    );
  }
}

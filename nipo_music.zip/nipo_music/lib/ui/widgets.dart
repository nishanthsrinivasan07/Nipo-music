import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../jamendo_api.dart';
import '../models.dart';
import '../player.dart';
import '../store.dart';
import '../theme.dart';
import 'detail.dart';

class Artwork extends StatelessWidget {
  final String url;
  final double size;
  final double radius;
  const Artwork(this.url, {super.key, this.size = 56, this.radius = 8});

  @override
  Widget build(BuildContext context) {
    final ph = Container(
      width: size, height: size,
      decoration: BoxDecoration(
          gradient: NipoColors.gradient, borderRadius: BorderRadius.circular(radius)),
      child: Icon(Icons.music_note_rounded, color: Colors.white70, size: size * 0.4),
    );
    if (url.isEmpty) return ph;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: CachedNetworkImage(
        imageUrl: url, width: size, height: size, fit: BoxFit.cover,
        placeholder: (_, __) => Container(width: size, height: size, color: NipoColors.surface2),
        errorWidget: (_, __, ___) => ph,
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;
  const SectionHeader(this.title, {super.key, this.subtitle, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 10),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -0.4)),
              if (subtitle != null && subtitle!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(subtitle!,
                      style: const TextStyle(color: NipoColors.textDim, fontSize: 12.5)),
                ),
            ]),
          ),
          if (trailing != null) trailing!,
        ]),
      );
}

/// Loading / error / empty states in one place.
class StateMessage extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? body;
  final String? action;
  final VoidCallback? onAction;
  const StateMessage(this.icon, this.title, {super.key, this.body, this.action, this.onAction});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 44, color: NipoColors.textDim),
            const SizedBox(height: 14),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            if (body != null) ...[
              const SizedBox(height: 6),
              Text(body!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: NipoColors.textDim, height: 1.35)),
            ],
            if (action != null) ...[
              const SizedBox(height: 16),
              FilledButton(onPressed: onAction, child: Text(action!)),
            ],
          ]),
        ),
      );
}

class Loading extends StatelessWidget {
  const Loading({super.key});
  @override
  Widget build(BuildContext context) => const Center(
      child: Padding(
          padding: EdgeInsets.all(40),
          child: CircularProgressIndicator(strokeWidth: 3, color: NipoColors.violet)));
}

StateMessage errorState(Object e, VoidCallback retry) {
  final missingKey = e is ApiException && e.message.contains('client ID');
  return StateMessage(
    missingKey ? Icons.key_rounded : Icons.cloud_off_rounded,
    missingKey ? 'Connect a music catalogue' : 'Something went wrong',
    body: '$e',
    action: missingKey ? null : 'Try again',
    onAction: retry,
  );
}

class TrackTile extends StatelessWidget {
  final Track track;
  final List<Track> context_;
  final bool showIndex;
  final int? index;
  final VoidCallback? onRemove;
  const TrackTile(this.track, this.context_,
      {super.key, this.showIndex = false, this.index, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final pc = context.watch<PlayerController>();
    final playing = pc.current?.id == track.id;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
      leading: showIndex
          ? SizedBox(width: 28, child: Center(child: Text('${(index ?? 0) + 1}',
              style: const TextStyle(color: NipoColors.textDim))))
          : Artwork(track.image),
      title: Text(track.title,
          maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontWeight: FontWeight.w600, color: playing ? NipoColors.pink : Colors.white)),
      subtitle: Text(track.artist,
          maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: NipoColors.textDim)),
      trailing: IconButton(
        icon: const Icon(Icons.more_horiz_rounded),
        onPressed: () => showTrackMenu(context, track, onRemove: onRemove),
      ),
      onTap: () => pc.playTrack(track, context: context_),
    );
  }
}

/// Horizontal row of square cards.
class TrackShelf extends StatelessWidget {
  final List<Track> tracks;
  const TrackShelf(this.tracks, {super.key});
  @override
  Widget build(BuildContext context) {
    final pc = context.read<PlayerController>();
    return SizedBox(
      height: 190,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: tracks.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (_, i) {
          final t = tracks[i];
          return GestureDetector(
            onTap: () => pc.playQueue(tracks, start: i),
            onLongPress: () => showTrackMenu(context, t),
            child: SizedBox(
              width: 140,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Artwork(t.image, size: 140, radius: 12),
                const SizedBox(height: 8),
                Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                Text(t.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: NipoColors.textDim, fontSize: 12)),
              ]),
            ),
          );
        },
      ),
    );
  }
}

void showTrackMenu(BuildContext context, Track t, {VoidCallback? onRemove}) {
  final store = context.read<LibraryStore>();
  final pc = context.read<PlayerController>();
  final nav = Navigator.of(context);
  final messenger = ScaffoldMessenger.of(context);
  showModalBottomSheet(
    context: context,
    backgroundColor: NipoColors.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (sheet) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
          leading: Artwork(t.image),
          title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(t.artist),
        ),
        const Divider(height: 1),
        ListTile(
          leading: Icon(store.isLiked(t) ? Icons.favorite : Icons.favorite_border,
              color: store.isLiked(t) ? NipoColors.pink : null),
          title: Text(store.isLiked(t) ? 'Remove from Liked Songs' : 'Add to Liked Songs'),
          onTap: () {
            store.toggleLike(t);
            Navigator.pop(sheet);
          },
        ),
        ListTile(
          leading: const Icon(Icons.queue_play_next_rounded),
          title: const Text('Play next'),
          onTap: () {
            pc.playNext(t);
            Navigator.pop(sheet);
            messenger.showSnackBar(const SnackBar(content: Text('Playing next')));
          },
        ),
        ListTile(
          leading: const Icon(Icons.queue_music_rounded),
          title: const Text('Add to queue'),
          onTap: () {
            pc.addToQueue(t);
            Navigator.pop(sheet);
            messenger.showSnackBar(const SnackBar(content: Text('Added to queue')));
          },
        ),
        ListTile(
          leading: const Icon(Icons.playlist_add_rounded),
          title: const Text('Add to playlist'),
          onTap: () {
            Navigator.pop(sheet);
            pickPlaylist(context, t);
          },
        ),
        if (t.artistId.isNotEmpty)
          ListTile(
            leading: const Icon(Icons.person_rounded),
            title: const Text('Go to artist'),
            onTap: () {
              Navigator.pop(sheet);
              nav.push(MaterialPageRoute(
                  builder: (_) => TrackListPage.artist(ArtistLite(t.artistId, t.artist, ''))));
            },
          ),
        if (t.albumId.isNotEmpty)
          ListTile(
            leading: const Icon(Icons.album_rounded),
            title: const Text('Go to album'),
            onTap: () {
              Navigator.pop(sheet);
              nav.push(MaterialPageRoute(
                  builder: (_) => TrackListPage.album(AlbumLite(t.albumId, t.album, t.artist, t.image))));
            },
          ),
        if (onRemove != null)
          ListTile(
            leading: const Icon(Icons.remove_circle_outline_rounded),
            title: const Text('Remove from this list'),
            onTap: () {
              onRemove();
              Navigator.pop(sheet);
            },
          ),
      ]),
    ),
  );
}

Future<String?> askText(BuildContext context, String title, {String initial = '', String hint = ''}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (d) => AlertDialog(
      backgroundColor: NipoColors.surface,
      title: Text(title),
      content: TextField(
          controller: c, autofocus: true, decoration: InputDecoration(hintText: hint),
          onSubmitted: (v) => Navigator.pop(d, v)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('OK')),
      ],
    ),
  );
}

void pickPlaylist(BuildContext context, Track t) {
  final store = context.read<LibraryStore>();
  showModalBottomSheet(
    context: context,
    backgroundColor: NipoColors.surface,
    builder: (sheet) => SafeArea(
      child: ListView(shrinkWrap: true, children: [
        ListTile(
          leading: const Icon(Icons.add_rounded),
          title: const Text('New playlist'),
          onTap: () async {
            Navigator.pop(sheet);
            final n = await askText(context, 'New playlist', hint: 'Name');
            if (n != null && n.trim().isNotEmpty) {
              store.addToPlaylist(store.createPlaylist(n), t);
            }
          },
        ),
        for (final p in store.playlists)
          ListTile(
            leading: const Icon(Icons.queue_music_rounded),
            title: Text(p.name),
            subtitle: Text('${p.tracks.length} songs'),
            onTap: () {
              store.addToPlaylist(p, t);
              Navigator.pop(sheet);
            },
          ),
      ]),
    ),
  );
}

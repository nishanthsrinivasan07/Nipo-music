import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../jamendo_api.dart';
import '../models.dart';
import '../recommender.dart';
import '../store.dart';
import '../theme.dart';
import 'settings.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Shelf>> _f;

  @override
  void initState() {
    super.initState();
    _f = context.read<Recommender>().homeShelves();
  }

  Future<void> _refresh() async {
    final f = context.read<Recommender>().homeShelves();
    setState(() => _f = f);
    try {
      await f;
    } catch (_) {}
  }

  String get _greeting {
    final h = DateTime.now().hour;
    return h < 5 ? 'Late night listening' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final api = context.read<JamendoApi>();
    return Scaffold(
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (r) => NipoColors.gradient.createShader(r),
          child: const Text('NIPO MUSIC', style: TextStyle(color: Colors.white)),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_rounded),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SettingsScreen())).then((_) {
              if (mounted) _refresh();
            }),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: NipoColors.violet,
        onRefresh: _refresh,
        child: FutureBuilder<List<Shelf>>(
          future: _f,
          builder: (c, snap) {
            final header = Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_greeting,
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: -0.8)),
                const Text('Music. Discovered differently.',
                    style: TextStyle(color: NipoColors.textDim)),
              ]),
            );
            if (snap.connectionState != ConnectionState.done) {
              return ListView(children: [header, const SizedBox(height: 80), const Loading()]);
            }
            if (snap.hasError) {
              return ListView(children: [
                header,
                SizedBox(
                  height: 420,
                  child: Builder(builder: (_) {
                    final e = snap.error!;
                    if (!api.hasKey) {
                      return StateMessage(Icons.key_rounded, 'Connect a music catalogue',
                          body: 'NIPO MUSIC streams licensed music from Jamendo. Add your free '
                              'Jamendo client ID to start listening.',
                          action: 'Open Settings',
                          onAction: () => Navigator.push(context,
                                  MaterialPageRoute(builder: (_) => const SettingsScreen()))
                              .then((_) => _refresh()));
                    }
                    return errorState(e, _refresh);
                  }),
                ),
              ]);
            }
            final shelves = snap.data!;
            return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
              header,
              if (store.recent.isNotEmpty) ...[
                const SectionHeader('Recently played'),
                TrackShelf(store.recent.take(15).toList()),
              ],
              for (final s in shelves) ...[
                SectionHeader(s.title, subtitle: s.subtitle),
                TrackShelf(s.tracks),
              ],
            ]);
          },
        ),
      ),
    );
  }
}

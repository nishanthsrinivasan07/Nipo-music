import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'detail.dart';
import 'widgets.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Library'),
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            indicatorColor: NipoColors.pink,
            tabs: [Tab(text: 'Liked'), Tab(text: 'Playlists'), Tab(text: 'Artists'), Tab(text: 'Recent')],
          ),
        ),
        body: TabBarView(children: [
          _tracks(store.likes, Icons.favorite_border_rounded, 'No liked songs yet',
              'Tap the heart in the player to keep songs here.'),
          _playlists(context, store),
          _artists(context, store),
          _tracks(store.recent, Icons.history_rounded, 'Nothing played yet',
              'Songs you listen to will show up here.',
              onClear: store.clearRecent),
        ]),
      ),
    );
  }

  Widget _tracks(List<Track> l, IconData icon, String t, String b, {VoidCallback? onClear}) {
    if (l.isEmpty) return StateMessage(icon, t, body: b);
    return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
      for (final x in l) TrackTile(x, l),
      if (onClear != null)
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextButton(onPressed: onClear, child: const Text('Clear history')),
        ),
    ]);
  }

  Widget _playlists(BuildContext context, LibraryStore store) {
    return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
      ListTile(
        leading: Container(
          width: 56, height: 56,
          decoration: BoxDecoration(
              color: NipoColors.surface2, borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.add_rounded),
        ),
        title: const Text('New playlist', style: TextStyle(fontWeight: FontWeight.w600)),
        onTap: () async {
          final n = await askText(context, 'New playlist', hint: 'Name');
          if (n != null && n.trim().isNotEmpty) store.createPlaylist(n);
        },
      ),
      if (store.playlists.isEmpty)
        const Padding(
          padding: EdgeInsets.all(32),
          child: Text('Create a playlist, then add songs from any ••• menu.',
              textAlign: TextAlign.center, style: TextStyle(color: NipoColors.textDim)),
        ),
      for (final p in store.playlists)
        ListTile(
          leading: Artwork(p.tracks.isEmpty ? '' : p.tracks.first.image),
          title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text('${p.tracks.length} songs',
              style: const TextStyle(color: NipoColors.textDim)),
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => PlaylistPage(p))),
        ),
    ]);
  }

  Widget _artists(BuildContext context, LibraryStore store) {
    if (store.favArtists.isEmpty) {
      return const StateMessage(Icons.person_outline_rounded, 'No favourite artists',
          body: 'Open an artist page and tap the heart.');
    }
    return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
      for (final a in store.favArtists)
        ListTile(
          leading: Artwork(a.image, radius: 28),
          title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w600)),
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => TrackListPage.artist(a))),
        ),
    ]);
  }
}

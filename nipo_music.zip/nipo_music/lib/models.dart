class Track {
  final String id, title, artist, artistId, album, albumId, image, audioUrl, license;
  final int duration; // seconds
  final List<String> tags;

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.artistId,
    required this.album,
    required this.albumId,
    required this.image,
    required this.audioUrl,
    required this.duration,
    this.license = '',
    this.tags = const [],
  });

  factory Track.fromJamendo(Map<String, dynamic> j) {
    final tags = <String>[];
    final mi = j['musicinfo'];
    if (mi is Map && mi['tags'] is Map) {
      for (final k in ['genres', 'vartags']) {
        final l = mi['tags'][k];
        if (l is List) tags.addAll(l.map((e) => e.toString().toLowerCase()));
      }
    }
    return Track(
      id: '${j['id']}',
      title: '${j['name'] ?? 'Unknown'}',
      artist: '${j['artist_name'] ?? 'Unknown artist'}',
      artistId: '${j['artist_id'] ?? ''}',
      album: '${j['album_name'] ?? ''}',
      albumId: '${j['album_id'] ?? ''}',
      image: '${j['image'] ?? j['album_image'] ?? ''}',
      audioUrl: '${j['audio'] ?? ''}',
      duration: int.tryParse('${j['duration'] ?? 0}') ?? 0,
      license: '${j['license_ccurl'] ?? ''}',
      tags: tags,
    );
  }

  factory Track.fromJson(Map<String, dynamic> j) => Track(
        id: j['id'],
        title: j['title'],
        artist: j['artist'],
        artistId: j['artistId'],
        album: j['album'],
        albumId: j['albumId'],
        image: j['image'],
        audioUrl: j['audioUrl'],
        duration: j['duration'],
        license: j['license'] ?? '',
        tags: List<String>.from(j['tags'] ?? []),
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'title': title, 'artist': artist, 'artistId': artistId,
        'album': album, 'albumId': albumId, 'image': image, 'audioUrl': audioUrl,
        'duration': duration, 'license': license, 'tags': tags,
      };
}

class ArtistLite {
  final String id, name, image;
  const ArtistLite(this.id, this.name, this.image);
  factory ArtistLite.fromJamendo(Map<String, dynamic> j) =>
      ArtistLite('${j['id']}', '${j['name']}', '${j['image'] ?? ''}');
  factory ArtistLite.fromJson(Map<String, dynamic> j) =>
      ArtistLite(j['id'], j['name'], j['image']);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'image': image};
}

class AlbumLite {
  final String id, name, artist, image;
  const AlbumLite(this.id, this.name, this.artist, this.image);
  factory AlbumLite.fromJamendo(Map<String, dynamic> j) => AlbumLite(
      '${j['id']}', '${j['name']}', '${j['artist_name'] ?? ''}', '${j['image'] ?? ''}');
}

class Playlist {
  String id, name;
  List<Track> tracks;
  Playlist(this.id, this.name, this.tracks);
  factory Playlist.fromJson(Map<String, dynamic> j) => Playlist(j['id'], j['name'],
      (j['tracks'] as List).map((e) => Track.fromJson(e)).toList());
  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'tracks': tracks.map((t) => t.toJson()).toList()};
}

/// A titled row of tracks on the Home / Discover screens.
class Shelf {
  final String title, subtitle;
  final List<Track> tracks;
  const Shelf(this.title, this.tracks, {this.subtitle = ''});
}

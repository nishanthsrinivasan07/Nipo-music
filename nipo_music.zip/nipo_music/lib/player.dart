import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'models.dart';
import 'store.dart';

/// Wraps just_audio. Background playback, the media notification and lock-screen
/// controls are provided by just_audio_background (Android MediaSession).
class PlayerController extends ChangeNotifier {
  final LibraryStore store;
  final AudioPlayer _player = AudioPlayer();
  ConcatenatingAudioSource _source = ConcatenatingAudioSource(children: []);
  List<Track> queue = [];
  int index = 0;
  String? error;
  bool loading = false;
  DateTime? _startedAt;
  Track? _prev;

  PlayerController(this.store);

  AudioPlayer get player => _player;
  Track? get current => (index >= 0 && index < queue.length) ? queue[index] : null;
  bool get hasTrack => current != null;

  Future<void> init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
    // Pause on interruptions (calls) and when headphones are unplugged.
    session.becomingNoisyEventStream.listen((_) => _player.pause());

    _player.currentIndexStream.listen((i) {
      if (i == null || i >= queue.length) return;
      _finishPrevious();
      index = i;
      final t = queue[i];
      _prev = t;
      _startedAt = DateTime.now();
      store.recordPlay(t);
      notifyListeners();
    });
    _player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      error = 'Playback problem: this track could not be streamed.';
      loading = false;
      notifyListeners();
    });
    _player.processingStateStream.listen((s) {
      loading = s == ProcessingState.loading || s == ProcessingState.buffering;
      if (s == ProcessingState.completed) _finishPrevious(completed: true);
      notifyListeners();
    });
  }

  /// Positive/negative taste signal from how long the previous track was heard.
  void _finishPrevious({bool completed = false}) {
    final t = _prev, s = _startedAt;
    if (t == null || s == null) return;
    final heard = DateTime.now().difference(s).inSeconds;
    if (completed || (t.duration > 0 && heard >= t.duration * 0.6)) {
      store.recordListenedThrough(t);
    } else if (heard < 15) {
      store.recordSkip(t);
    }
    _prev = null;
    _startedAt = null;
  }

  AudioSource _src(Track t) => AudioSource.uri(
        Uri.parse(t.audioUrl),
        tag: MediaItem(
          id: t.id,
          title: t.title,
          artist: t.artist,
          album: t.album,
          artUri: t.image.isEmpty ? null : Uri.tryParse(t.image),
          duration: t.duration > 0 ? Duration(seconds: t.duration) : null,
        ),
      );

  Future<void> playQueue(List<Track> tracks, {int start = 0}) async {
    if (tracks.isEmpty) return;
    error = null;
    queue = List.of(tracks);
    index = start;
    _source = ConcatenatingAudioSource(children: queue.map(_src).toList());
    notifyListeners();
    try {
      await _player.setAudioSource(_source, initialIndex: start, initialPosition: Duration.zero);
      _player.play();
    } catch (e) {
      error = 'Could not start playback. Check your connection and try again.';
      notifyListeners();
    }
  }

  Future<void> playTrack(Track t, {List<Track>? context}) async {
    final list = context ?? [t];
    final i = list.indexWhere((e) => e.id == t.id);
    await playQueue(list, start: i < 0 ? 0 : i);
  }

  Future<void> addToQueue(Track t) async {
    if (queue.isEmpty) return playQueue([t]);
    queue.add(t);
    await _source.add(_src(t));
    notifyListeners();
  }

  Future<void> playNext(Track t) async {
    if (queue.isEmpty) return playQueue([t]);
    final at = index + 1;
    queue.insert(at, t);
    await _source.insert(at, _src(t));
    notifyListeners();
  }

  Future<void> removeFromQueue(int i) async {
    if (i < 0 || i >= queue.length) return;
    queue.removeAt(i);
    await _source.removeAt(i);
    if (queue.isEmpty) await _player.stop();
    notifyListeners();
  }

  Future<void> moveInQueue(int from, int to) async {
    if (from == to) return;
    final t = queue.removeAt(from);
    queue.insert(to, t);
    await _source.move(from, to);
    notifyListeners();
  }

  Future<void> jumpTo(int i) async {
    await _player.seek(Duration.zero, index: i);
    _player.play();
  }

  void togglePlay() => _player.playing ? _player.pause() : _player.play();
  Future<void> next() => _player.seekToNext();
  Future<void> previous() async {
    if (_player.position > const Duration(seconds: 4)) {
      await _player.seek(Duration.zero);
    } else {
      await _player.seekToPrevious();
    }
  }

  Future<void> seek(Duration d) => _player.seek(d);

  Future<void> toggleShuffle() async {
    final on = !_player.shuffleModeEnabled;
    if (on) await _player.shuffle();
    await _player.setShuffleModeEnabled(on);
    notifyListeners();
  }

  Future<void> cycleRepeat() async {
    final m = _player.loopMode;
    await _player.setLoopMode(m == LoopMode.off
        ? LoopMode.all
        : m == LoopMode.all
            ? LoopMode.one
            : LoopMode.off);
    notifyListeners();
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
